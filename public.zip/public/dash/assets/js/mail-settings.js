$(function(e) {
	'use strict'
	
	//select2 dropdown
	$('.select2').select2({
		minimumResultsForSearch: Infinity,
		width: '100%'
	  });
});