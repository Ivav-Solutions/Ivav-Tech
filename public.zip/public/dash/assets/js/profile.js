(function ($) {
    "use strict";
    
    // Select2 
	$('.select2').select2({
		minimumResultsForSearch: Infinity
	});

})(jQuery);